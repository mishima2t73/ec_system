<?php
/**
 * WordPress の基本設定
 *
 * このファイルは、インストール時に wp-config.php 作成ウィザードが利用します。
 * ウィザードを介さずにこのファイルを "wp-config.php" という名前でコピーして
 * 直接編集して値を入力してもかまいません。
 *
 * このファイルは、以下の設定を含みます。
 *
 * * MySQL 設定
 * * 秘密鍵
 * * データベーステーブル接頭辞
 * * ABSPATH
 *
 * @link https://ja.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// 注意:
// Windows の "メモ帳" でこのファイルを編集しないでください !
// 問題なく使えるテキストエディタ
// (http://wpdocs.osdn.jp/%E7%94%A8%E8%AA%9E%E9%9B%86#.E3.83.86.E3.82.AD.E3.82.B9.E3.83.88.E3.82.A8.E3.83.87.E3.82.A3.E3.82.BF 参照)
// を使用し、必ず UTF-8 の BOM なし (UTF-8N) で保存してください。

// ** MySQL 設定 - この情報はホスティング先から入手してください。 ** //
/** WordPress のためのデータベース名 */
define( 'DB_NAME', 'wordpress' );

/** MySQL データベースのユーザー名 */
define( 'DB_USER', 'root' );

/** MySQL データベースのパスワード */
define( 'DB_PASSWORD', '0305' );

/** MySQL のホスト名 */
define( 'DB_HOST', 'localhost' );

/** データベースのテーブルを作成する際のデータベースの文字セット */
define( 'DB_CHARSET', 'utf8mb4' );

/** データベースの照合順序 (ほとんどの場合変更する必要はありません) */
define( 'DB_COLLATE', '' );

/**#@+
 * 認証用ユニークキー
 *
 * それぞれを異なるユニーク (一意) な文字列に変更してください。
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org の秘密鍵サービス} で自動生成することもできます。
 * 後でいつでも変更して、既存のすべての cookie を無効にできます。これにより、すべてのユーザーを強制的に再ログインさせることになります。
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '<WF[Wi5:+~0~-Zbxg>2G-w5ek_Q6Sx)TK9=%AS0tC*Lh]JZBg@56ad$YQGvL5#JT' );
define( 'SECURE_AUTH_KEY',  'k!lMP7>%u|`P&H}BQU6rnPQv^K|k%JxPl_lv2QY)5()x&Kg=xikeGO>J}O`N55p)' );
define( 'LOGGED_IN_KEY',    'KYOF1pWr#zD>{k _XYi#r6_|7.^?>e2UnY16-j|L~Ibg0cMcOzvrBH^d[_d2q?#3' );
define( 'NONCE_KEY',        '_jJbpXd-cdmST+LR0R2A,.<Tl)kI[/o07+(A~|~Wr>X~.JUnKtS*c{@c26F%(uKN' );
define( 'AUTH_SALT',        'FcC}HDCYxX/lH%MdZ*7Q3]3v19.E$~Q)U~.8C l0d3#ZKwY-puZr`}Fekr6/PjF1' );
define( 'SECURE_AUTH_SALT', ')DvUq4;&r`~QB5n_dz]wCcTHuAO(n1ZRfj&6J Z:k,1cQLN-.O2HK:k7tr5T>Zc/' );
define( 'LOGGED_IN_SALT',   'E>ADD_b~}n/~F4KQ,f,kPDto_TulXB^Bvb07Xjiq^<*G_s:p,t]:UnA_D8ry;e~o' );
define( 'NONCE_SALT',       '$}4YK:9$M=z?gz5aN%0Zo?}Nnv6RsP)%l~QJ9ZM|Z,P3nZORkBv{I9|T]Zj9ZDGY' );

/**#@-*/

/**
 * WordPress データベーステーブルの接頭辞
 *
 * それぞれにユニーク (一意) な接頭辞を与えることで一つのデータベースに複数の WordPress を
 * インストールすることができます。半角英数字と下線のみを使用してください。
 */
$table_prefix = 'wp_';

/**
 * 開発者へ: WordPress デバッグモード
 *
 * この値を true にすると、開発中に注意 (notice) を表示します。
 * テーマおよびプラグインの開発者には、その開発環境においてこの WP_DEBUG を使用することを強く推奨します。
 *
 * その他のデバッグに利用できる定数についてはドキュメンテーションをご覧ください。
 *
 * @link https://ja.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* 編集が必要なのはここまでです ! WordPress でのパブリッシングをお楽しみください。 */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
